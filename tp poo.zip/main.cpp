#include <iostream>
#include <string>
#include <vector>

#include "pessoa.h"
#include "menu.h"

using namespace std;
int main(int argc, char *argv[]){
    menu_inicial();
}