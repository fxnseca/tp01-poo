#ifndef MENU_H
#define MENU_H

void menu_inicial();
void menu_chefe();
void menu_funcionario();

#endif